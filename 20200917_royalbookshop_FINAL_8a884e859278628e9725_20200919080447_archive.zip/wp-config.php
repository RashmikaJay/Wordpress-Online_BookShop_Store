<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://codex.wordpress.org/Editing_wp-config.php

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         '2DJB~f7+u!H9QmL5UMWlpVyKxP|YEmj_sCjA#V$=,_EPIfdk&S9P>uUXhX#zDc/s' );

define( 'SECURE_AUTH_KEY',  '!XTT)L]p17VXN>m|$1Ul{Y&J 6Oe<yPnA[]Xj/FkQ1AA+8l/c*s$3T[pY.YhxeYw' );

define( 'LOGGED_IN_KEY',    '*Zkw<HZ&E0}1 -2RVw{wLHIGa%n} 5gp`--^_c)z!{a]n-L0d|Z;(bDX]xD%qrwY' );

define( 'NONCE_KEY',        '!6XX,oFsv1ENh0-|%g<[Y4*tS)7shtXLcEd`MvTL8`=L5{JU3*k%A>`#a6:E^ou^' );

define( 'AUTH_SALT',        '6_FHN^Zq)gMA{a3JqkCn+2[)K}cUL*3{ovo]JNE1x2>eI=AgQW6u[sr6QncA#OvJ' );

define( 'SECURE_AUTH_SALT', '/WEEBW ]k<X]S(XY-02`v9NqBm-XRWz-<JGLer^>S|-O}T5` =[mDfA-vYMpd!rF' );

define( 'LOGGED_IN_SALT',   'Z}4{}_jp4n?WQ-pOJ],3z?L(tf46#*LfS_$ZI:he;kAD+f|0C#|<ThxO>=1BN`-~' );

define( 'NONCE_SALT',       '1bf.r{mB-Ldk50lJ}2z|fhhK,nH(NEX43PlqlC!;xc~j3>zwd5jbgJH[D=}tD,A<' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the Codex.

 *

 * @link https://codex.wordpress.org/Debugging_in_WordPress

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

}


/** Sets up WordPress vars and included files. */

require_once( ABSPATH . 'wp-settings.php' );

